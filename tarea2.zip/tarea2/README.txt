Marco Antonio Orduña Avila - 315019928

Tarea 2. Crear un programa para calcular la puntuación de un jugador en un torneo
según el sistema de puntuación de Elo 

para ejecutar el programa solo basta con situarse en la carpeta pricipar del programa 
y ejecutar el siguiente comando:

$ python3 main.py
